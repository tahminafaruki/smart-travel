document.addEventListener('DOMContentLoaded', function () {
    const sections = document.querySelectorAll('.content-section');
    const buttons = document.querySelectorAll('.sidebar button');

    buttons.forEach(button => {
        button.addEventListener('click', function () {
            sections.forEach(section => section.classList.remove('active'));
            document.getElementById(button.dataset.sectionId).classList.add('active');
        });
    });

    document.getElementById('logoutButton').addEventListener('click', function () {
        window.location.href = 'admin.html';
    });

    // Add more JavaScript for handling form submissions and data fetching
});
