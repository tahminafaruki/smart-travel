<?php
// Database connection
$servername = "localhost";
$username = "root"; // Replace with your DB username
$password = ""; // Replace with your DB password
$dbname = "travelss"; // Database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Initialize error and success messages
$errorMessage = $successMessage = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);
    $confirmPassword = $conn->real_escape_string($_POST['confirmPassword']);

    // Validate passwords
    if ($password !== $confirmPassword) {
        $errorMessage = "Passwords do not match!";
    } else {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Insert into database
        $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashedPassword')";

        if ($conn->query($sql) === TRUE) {
            $successMessage = "Registration successful! You can now log in.";
        } else {
            $errorMessage = "Error: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <link rel="stylesheet" href="./scss/registration.css">
</head>
<body>
<div class="wrapper">
  <h2>SignUp</h2>
  <!-- Display Error/Success Messages -->
  <?php if (!empty($errorMessage)): ?>
    <div class="error" style="color: red; text-align: center;"><?php echo $errorMessage; ?></div>
  <?php endif; ?>
  <?php if (!empty($successMessage)): ?>
    <div class="success" style="color: green; text-align: center;"><?php echo $successMessage; ?></div>
  <?php endif; ?>

  <form id="registrationForm" method="POST" action="">
    <div class="input-box">
      <input id="usernameInput" name="username" type="text" placeholder="Enter your username" required>
    </div>
    <div class="input-box">
      <input id="emailInput" name="email" type="email" placeholder="Enter your email" required>
    </div>
    <div class="input-box">
      <input id="passwordInput" name="password" type="password" placeholder="Create password" required>
    </div>
    <div class="input-box">
      <input id="confirmPasswordInput" name="confirmPassword" type="password" placeholder="Confirm password" required>
    </div>

    <div class="input-box button">
      <input type="submit" value="SignUp">
    </div>
    <div class="text">
      <h3>Already have an account? <a href="./Login.html">Login now</a></h3>
    </div>
  </form>
</div>
</body>
</html>



